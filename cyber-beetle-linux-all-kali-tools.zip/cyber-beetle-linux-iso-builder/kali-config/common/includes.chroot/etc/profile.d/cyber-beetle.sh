case "$-" in
  *i*) command -v cyber-beetle-welcome >/dev/null 2>&1 && cyber-beetle-welcome ;;
esac
