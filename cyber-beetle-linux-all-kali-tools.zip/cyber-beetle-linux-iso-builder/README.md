# Cyber Beetle Linux — amd64 live ISO builder

This project builds a bootable x86_64/amd64 Kali-based live ISO with Cyber Beetle branding.
The same ISO can boot in VirtualBox, VMware or QEMU and from a USB drive on a compatible PC.

**This ZIP is build source, not a compiled ISO.** The ISO must be built on your Linux machine;
the process downloads Kali's base system and packages.

## Requirements
- Kali Linux preferred; current Debian/Ubuntu may work
- x86_64 / amd64
- Internet and sudo access
- At least 100 GB free disk is recommended for building; 8–16 GB RAM is recommended. The installed Everything desktop footprint is roughly 34–36 GB according to Kali's published sizing guide.

## Build
Extract the ZIP, open a terminal in the extracted directory, then run:

```bash
chmod +x scripts/*.sh
sudo ./scripts/build-live-iso.sh
```

Wait for the build to finish. It can take a long time and download several GB.
The `.iso` and `SHA256SUMS` should appear in `output/`.

## Test with QEMU
Install QEMU if needed:

```bash
sudo apt update
sudo apt install -y qemu-system-x86
./scripts/test-with-qemu.sh output/NAME-OF-IMAGE.iso
```

For VirtualBox/VMware, create a 64-bit Debian/Kali VM, assign at least 4 GB RAM, attach the
ISO as its optical drive and boot. Use the live option to try without changing a virtual disk.
A live ISO is not necessarily an installer image.

## Write USB
Identify the correct whole USB device first:

```bash
lsblk -o NAME,SIZE,MODEL,TRAN,MOUNTPOINTS
sudo ./scripts/write-usb-linux.sh output/NAME-OF-IMAGE.iso /dev/sdX
```

Replace `/dev/sdX` with the correct whole device, not a partition such as `/dev/sdX1`.
**This erases the selected USB drive.** Confirm its model and size before continuing.

## Included
- Kali XFCE desktop base and Kali Everything metapackage
- Tor Browser launcher (downloads Tor Browser on first launch)
- Firefox ESR and Wireshark
- Cyber Beetle wallpaper and terminal welcome banner

This is an unofficial community remix, not an official Kali release. Kali's live-build scripts and
package names change; consult the current official guide if the build fails:
https://www.kali.org/docs/development/live-build-a-custom-kali-iso/

Use security tools only on systems you own or are explicitly authorized to test.


## Complete Kali tool collection (all-tools edition)

The build package list includes `kali-linux-everything`, Kali's official metapackage
described by Kali as "Every tool in Kali Linux". It pulls in Kali's specific-purpose
tool metapackages and their dependencies. The count of tools is not a fixed 345:
Kali's repository changes as tools are added, removed, renamed, or split into packages.
The official current catalogue is https://www.kali.org/tools/all-tools/.

This is a very large install. Not every package is suitable for every machine; some
require specialist wireless, Bluetooth, SDR, GPU, or other hardware. A live ISO with
the entire collection can become extremely large, and a build may fail if the host
runs out of disk space or a package is temporarily unavailable.
