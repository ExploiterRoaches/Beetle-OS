#!/usr/bin/env bash
set -euo pipefail
PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BUILD_DIR="${PROJECT_DIR}/work/kali-live"
OUTPUT_DIR="${PROJECT_DIR}/output"
REPO="https://gitlab.com/kalilinux/build-scripts/kali-live.git"

[[ "$(dpkg --print-architecture 2>/dev/null || true)" == "amd64" ]] || {
  echo "This build targets amd64 (x86_64)."; exit 1;
}
[[ "${EUID}" -eq 0 ]] || { echo "Run with sudo: sudo $0"; exit 1; }
command -v apt-get >/dev/null 2>&1 || {
  echo "This helper supports Kali/Debian/Ubuntu hosts with apt."; exit 1;
}

export DEBIAN_FRONTEND=noninteractive
apt-get update
apt-get install -y git live-build cdebootstrap curl ca-certificates
mkdir -p "${PROJECT_DIR}/work" "${OUTPUT_DIR}"

if [[ ! -d "${BUILD_DIR}/.git" ]]; then
  git clone --depth 1 "${REPO}" "${BUILD_DIR}"
else
  git -C "${BUILD_DIR}" pull --ff-only
fi

mkdir -p "${BUILD_DIR}/kali-config/variant-default/package-lists"
cp -a "${PROJECT_DIR}/kali-config/variant-default/package-lists/." \
  "${BUILD_DIR}/kali-config/variant-default/package-lists/"
cp -a "${PROJECT_DIR}/kali-config/common/includes.chroot/." \
  "${BUILD_DIR}/kali-config/common/includes.chroot/"

cd "${BUILD_DIR}"
./build.sh --arch amd64 --variant xfce --verbose
find "${BUILD_DIR}" -type f -name '*.iso' -exec cp -v {} "${OUTPUT_DIR}/" \;
if ! find "${OUTPUT_DIR}" -maxdepth 1 -type f -name '*.iso' -print -quit | grep -q .; then
  echo "No ISO found. Inspect build.log and Kali's current build documentation."; exit 2;
fi
(cd "${OUTPUT_DIR}" && sha256sum *.iso > SHA256SUMS)
echo "Build complete. ISO and SHA256SUMS are in ${OUTPUT_DIR}"
