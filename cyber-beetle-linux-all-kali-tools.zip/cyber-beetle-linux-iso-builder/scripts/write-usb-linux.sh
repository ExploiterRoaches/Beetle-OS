#!/usr/bin/env bash
set -euo pipefail
[[ $# -eq 2 ]] || { echo "Usage: sudo $0 /path/to/image.iso /dev/sdX"; exit 1; }
ISO="$1"; DEVICE="$2"
[[ -f "$ISO" && -b "$DEVICE" && "$EUID" -eq 0 ]] || {
  echo "Check ISO, whole-device path, and sudo privileges."; exit 1;
}
echo "WARNING: ALL DATA ON $DEVICE WILL BE DESTROYED."
lsblk -o NAME,SIZE,MODEL,TRAN,MOUNTPOINTS "$DEVICE"
read -r -p "Type WIPE to continue: " answer
[[ "$answer" == "WIPE" ]] || exit 1
while read -r part; do
  [[ -n "$part" ]] && umount "$part" 2>/dev/null || true
done < <(lsblk -lnpo NAME "$DEVICE" | tail -n +2)
dd if="$ISO" of="$DEVICE" bs=4M status=progress conv=fsync
sync
echo "USB written. Boot the computer from this USB device."
