#!/usr/bin/env bash
set -euo pipefail
ISO="${1:-}"
[[ -f "$ISO" ]] || { echo "Usage: $0 /path/to/cyber-beetle.iso"; exit 1; }
command -v qemu-system-x86_64 >/dev/null 2>&1 || {
  echo "Install QEMU: sudo apt install qemu-system-x86"; exit 1;
}
qemu-system-x86_64 -m 4096 -smp 2 -enable-kvm -cdrom "$ISO" -boot d
